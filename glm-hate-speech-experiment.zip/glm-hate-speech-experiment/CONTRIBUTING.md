# Contributing

Thanks for your interest in improving this project.

## Workflow

1. Fork the repository.
2. Create a feature branch.
3. Make focused changes with clear commit messages.
4. Run basic checks before opening a pull request.
5. Open a PR with context: purpose, changes, and verification steps.

## Local Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -r requirements.txt
```

## Before Submitting

- Do not commit secrets (API keys, tokens, `.env`).
- Do not add machine-specific absolute paths.
- Keep notebooks cleared of execution outputs.
- Confirm data/model files are legally redistributable.
