"""
训练和推理相关的工具函数
"""
import re
import random
from typing import List, Dict
from collections import Counter
from tqdm import tqdm


# 定义标签映射（VERBALIZER）
VERBALIZER = {
    'toxic': {
        0: '非毒性内容',
        1: '含有毒性内容'
    },
    'toxic_type': {
        0: '非毒',
        1: '一般冒犯',
        2: '仇恨言论'
    },
    'expression': {
        0: '非仇恨',
        1: '显式仇恨',
        2: '隐式仇恨',
        3: '报道'
    },
    'target': {
        'LGBTQ': 'LGBTQ群体',
        '地域': '地域群体',
        '性别': '性别群体',
        '种族': '种族群体',
        '其他': '其他群体',
        '非仇恨': '非仇恨'
    }
}

# 反向映射：从中文标签到数字
REVERSE_VERBALIZER = {
    'toxic': {v: k for k, v in VERBALIZER['toxic'].items()},
    'toxic_type': {v: k for k, v in VERBALIZER['toxic_type'].items()},
    'expression': {v: k for k, v in VERBALIZER['expression'].items()},
    'target': {v: k for k, v in VERBALIZER['target'].items()}
}


def convert_target_list_to_names(target_list: List) -> List[str]:
    """将target列表（如[0,0,1,0,0]）转换为target名称列表"""
    target_names = ['地域', 'LGBTQ', '性别', '种族', '其他']
    result = []
    if isinstance(target_list, list):
        for idx, val in enumerate(target_list):
            if val == 1 and idx < len(target_names):
                result.append(target_names[idx])
    return result if result else ['非仇恨']


def convert_label_to_chinese(label_dict: Dict) -> Dict:
    """将数字标签转换为中文标签"""
    return {
        'toxic': VERBALIZER['toxic'][label_dict.get('toxic', 0)],
        'toxic_type': VERBALIZER['toxic_type'][label_dict.get('toxic_type', 0)],
        'expression': VERBALIZER['expression'][label_dict.get('expression', 0)],
        'target': [VERBALIZER['target'].get(t, '非仇恨') for t in label_dict.get('target', [])]
    }


def truncate_repetitive_content(text: str) -> str:
    """检测并截断重复生成的内容"""
    # 检测是否包含重复的提示词模式
    stop_patterns = [
        "\n\n请分析文本：",
        "\n\n你的判断：",
        "\n\n分析结果：",
        "\n\n判断：",
        "\n\n输入：",
    ]
    
    # 找到第一个停止模式的位置
    min_pos = len(text)
    for pattern in stop_patterns:
        pos = text.find(pattern)
        if pos != -1 and pos < min_pos:
            min_pos = pos
    
    # 如果找到停止模式，截断到该位置
    if min_pos < len(text):
        text = text[:min_pos]
    
    # 检测重复的句子模式（如果同一句话重复3次以上）
    lines = text.split('\n')
    if len(lines) > 3:
        # 检查是否有重复的句子
        seen = set()
        result_lines = []
        for line in lines:
            line_stripped = line.strip()
            if line_stripped and line_stripped not in seen:
                seen.add(line_stripped)
                result_lines.append(line)
            elif line_stripped in seen:
                # 如果遇到重复的句子，停止添加
                break
        if len(result_lines) < len(lines):
            text = '\n'.join(result_lines)
    
    return text.strip()


def vllm_batch_inference(llm, sampling_params, prompts: List[str], batch_size: int = 32) -> List[str]:
    """
    使用vLLM进行批量推理，并自动截断重复内容
    
    Args:
        llm: vLLM模型实例
        sampling_params: 采样参数
        prompts: 提示词列表
        batch_size: 批次大小
        
    Returns:
        响应文本列表
    """
    all_responses = []
    for i in tqdm(range(0, len(prompts), batch_size), desc="vLLM推理"):
        batch_prompts = prompts[i:i+batch_size]
        outputs = llm.generate(batch_prompts, sampling_params)
        for output in outputs:
            response = output.outputs[0].text
            
            # 后处理：检测并截断重复内容
            response = truncate_repetitive_content(response)
            
            all_responses.append(response)
    return all_responses


def vllm_batch_inference_autocot(llm, base_sampling_params, prompts: List[str], batch_size: int = 32, max_tokens: int = 1024) -> List[str]:
    """
    专门用于Auto-CoT实验的批量推理函数，放宽输出长度限制
    
    Auto-CoT的prompt较长，且需要生成完整的思考过程，因此需要更大的max_tokens。
    此函数会创建新的采样参数，增加max_tokens，同时保留其他参数设置。
    
    Args:
        llm: vLLM模型实例
        base_sampling_params: 基础采样参数（会复制并修改max_tokens）
        prompts: 提示词列表
        batch_size: 批次大小
        max_tokens: 最大生成token数（默认1024，适合CoT推理）
        
    Returns:
        响应文本列表
    """
    from vllm import SamplingParams
    
    # 创建新的采样参数，增加max_tokens，保留其他设置
    autocot_sampling_params = SamplingParams(
        temperature=base_sampling_params.temperature,
        top_p=base_sampling_params.top_p,
        max_tokens=max_tokens,  # 使用更大的max_tokens
        stop=base_sampling_params.stop,  # 保留停止token设置
        # 保留其他可能的参数
    )
    
    all_responses = []
    for i in tqdm(range(0, len(prompts), batch_size), desc="vLLM推理(Auto-CoT)"):
        batch_prompts = prompts[i:i+batch_size]
        outputs = llm.generate(batch_prompts, autocot_sampling_params)
        for output in outputs:
            response = output.outputs[0].text
            
            # 后处理：检测并截断重复内容（但保留完整的思考过程）
            # 对于CoT，我们只截断明显的重复，保留思考链
            response = truncate_repetitive_content(response)
            
            all_responses.append(response)
    return all_responses


def vote_for_answer(predictions: List[Dict], k: int) -> tuple:
    """
    投票决定最终答案（自一致性）
    
    Args:
        predictions: 预测结果列表
        k: 采样次数
        
    Returns:
        (final_answer, consistency_scores) 元组
    """
    final_answer = {}
    consistency_scores = {}
    
    for field in ['toxic', 'toxic_type', 'expression']:
        values = [p.get(field, 0) for p in predictions]
        counter = Counter(values)
        max_count = counter.most_common(1)[0][1]
        most_common_values = [val for val, count in counter.items() if count == max_count]
        final_answer[field] = random.choice(most_common_values)
        consistency_scores[field] = max_count / k
    
    # 目标群体投票
    target_votes = Counter()
    for p in predictions:
        targets = p.get('target', [])
        if isinstance(targets, list):
            for t in targets:
                target_votes[t] += 1
    
    final_answer['target'] = [t for t, count in target_votes.items() if count >= k / 2]
    consistency_scores['target'] = max(target_votes.values()) / k if target_votes else 0.0
    
    return final_answer, consistency_scores


def calculate_metrics(y_true: List, y_pred: List, label_type: str = 'multiclass') -> Dict:
    """
    计算准确率、精确率、召回率、F1分数
    
    Args:
        y_true: 真实标签列表
        y_pred: 预测标签列表
        label_type: 'binary'（二分类）或 'multiclass'（多分类）
        
    Returns:
        包含accuracy, precision, recall, f1的字典
    """
    try:
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
        
        acc = accuracy_score(y_true, y_pred)
        
        # 根据标签类型选择不同的average方式
        if label_type == 'binary':
            # 二分类：使用binary模式
            precision = precision_score(y_true, y_pred, average='binary', zero_division=0)
            recall = recall_score(y_true, y_pred, average='binary', zero_division=0)
            f1 = f1_score(y_true, y_pred, average='binary', zero_division=0)
        else:
            # 多分类：使用macro平均（考虑所有类别）
            precision = precision_score(y_true, y_pred, average='macro', zero_division=0)
            recall = recall_score(y_true, y_pred, average='macro', zero_division=0)
            f1 = f1_score(y_true, y_pred, average='macro', zero_division=0)
    except ImportError:
        # 如果sklearn不可用，手动计算
        correct = sum(1 for t, p in zip(y_true, y_pred) if t == p)
        acc = correct / len(y_true) if y_true else 0
        
        # 简化的precision和recall计算
        true_positives = sum(1 for t, p in zip(y_true, y_pred) if t == p and t == 1)
        predicted_positives = sum(1 for p in y_pred if p == 1)
        actual_positives = sum(1 for t in y_true if t == 1)
        
        precision = true_positives / predicted_positives if predicted_positives > 0 else 0
        recall = true_positives / actual_positives if actual_positives > 0 else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
    
    return {
        'accuracy': acc,
        'precision': precision,
        'recall': recall,
        'f1': f1
    }


def evaluate_results(results: List[Dict]) -> Dict:
    """
    评估结果，计算全局的precision、recall、f1和accuracy
    
    Args:
        results: 结果列表，每个元素包含true_label_num和predicted_label_num
        
    Returns:
        包含全局指标的字典：accuracy, precision, recall, f1
    """
    if not results:
        return {
            'accuracy': 0.0,
            'precision': 0.0,
            'recall': 0.0,
            'f1': 0.0
        }
    
    # 收集所有字段的预测和真实值
    all_y_true = []
    all_y_pred = []
    
    # 处理toxic, toxic_type, expression字段（单值字段）
    for field in ['toxic', 'toxic_type', 'expression']:
        for r in results:
            all_y_true.append(r['true_label_num'][field])
            all_y_pred.append(r['predicted_label_num'][field])
    
    # 处理target字段（多标签，转换为是否完全匹配）
    for r in results:
        true_targets = r['true_label_num'].get('target', [])
        pred_targets = r['predicted_label_num'].get('target', [])
        true_set = set(true_targets) if isinstance(true_targets, list) else set([true_targets])
        pred_set = set(pred_targets) if isinstance(pred_targets, list) else set([pred_targets])
        # 将target的匹配情况转换为0/1（1表示完全匹配）
        all_y_true.append(1 if true_set == pred_set else 0)
        all_y_pred.append(1 if true_set == pred_set else 0)
    
    # 计算全局指标
    try:
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
        
        accuracy = accuracy_score(all_y_true, all_y_pred)
        precision = precision_score(all_y_true, all_y_pred, average='macro', zero_division=0)
        recall = recall_score(all_y_true, all_y_pred, average='macro', zero_division=0)
        f1 = f1_score(all_y_true, all_y_pred, average='macro', zero_division=0)
    except ImportError:
        # 如果sklearn不可用，手动计算
        correct = sum(1 for t, p in zip(all_y_true, all_y_pred) if t == p)
        accuracy = correct / len(all_y_true) if all_y_true else 0
        
        # 计算macro平均的precision和recall
        unique_labels = set(all_y_true + all_y_pred)
        precisions = []
        recalls = []
        
        for label in unique_labels:
            tp = sum(1 for t, p in zip(all_y_true, all_y_pred) if t == label and p == label)
            fp = sum(1 for t, p in zip(all_y_true, all_y_pred) if t != label and p == label)
            fn = sum(1 for t, p in zip(all_y_true, all_y_pred) if t == label and p != label)
            
            p = tp / (tp + fp) if (tp + fp) > 0 else 0
            r = tp / (tp + fn) if (tp + fn) > 0 else 0
            
            precisions.append(p)
            recalls.append(r)
        
        precision = sum(precisions) / len(precisions) if precisions else 0
        recall = sum(recalls) / len(recalls) if recalls else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
    
    return {
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1
    }
