#!/usr/bin/env python3
"""验证 _sft 响应文件的评估指标"""
import json
import joblib
import os
import sys
sys.path.insert(0, os.path.dirname(__file__))
from utils import VERBALIZER, convert_target_list_to_names, convert_label_to_chinese, evaluate_results
from ape_parser import parse_ape_response
from collections import Counter
import random

WORK_DIR = os.path.dirname(__file__)
DATA_PATH = os.path.join(os.path.dirname(__file__), '..', 'data', 'processed', 'standard', 'test.json')

def main():
    with open(DATA_PATH, 'r', encoding='utf-8') as f:
        test_data = json.load(f)
    
    files = ['baseline_responses_sft', 'ape_responses_sft', 'autocot_responses_sft', 'selfconsistency_responses_sft']
    
    for fname in files:
        path = os.path.join(WORK_DIR, fname)
        if not os.path.exists(path):
            print(f"⚠ 不存在: {fname}")
            continue
            
        data = joblib.load(path)
        
        if 'selfconsistency' in fname:
            # 投票逻辑
            K = 5
            results_for_eval = []
            for idx, (sample, k_responses) in enumerate(zip(test_data, data)):
                k_predictions = [parse_ape_response(r) for r in k_responses]
                final_answer = {}
                for field in ['toxic', 'toxic_type', 'expression']:
                    values = [p.get(field, 0) for p in k_predictions]
                    counter = Counter(values)
                    final_answer[field] = counter.most_common(1)[0][0]
                target_votes = Counter()
                for p in k_predictions:
                    for t in p.get('target', []):
                        target_votes[t] += 1
                final_answer['target'] = [t for t, c in target_votes.items() if c >= K/2]
                
                results_for_eval.append({
                    'true_label_num': {
                        'toxic': sample.get('toxic', 0),
                        'toxic_type': sample.get('toxic_type', 0),
                        'expression': sample.get('expression', 0),
                        'target': convert_target_list_to_names(sample.get('target', []))
                    },
                    'predicted_label_num': final_answer
                })
        else:
            results_for_eval = []
            for idx, (sample, response) in enumerate(zip(test_data, data)):
                pred = parse_ape_response(response)
                results_for_eval.append({
                    'true_label_num': {
                        'toxic': sample.get('toxic', 0),
                        'toxic_type': sample.get('toxic_type', 0),
                        'expression': sample.get('expression', 0),
                        'target': convert_target_list_to_names(sample.get('target', []))
                    },
                    'predicted_label_num': pred
                })
        
        metrics = evaluate_results(results_for_eval)
        print(f"\n{fname}:")
        print(f"  Accuracy:  {metrics['accuracy']:.4f}")
        print(f"  Precision: {metrics['precision']:.4f}")
        print(f"  Recall:    {metrics['recall']:.4f}")
        print(f"  F1 Score:  {metrics['f1']:.4f}")

if __name__ == '__main__':
    main()
