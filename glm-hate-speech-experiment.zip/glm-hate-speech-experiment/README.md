# GLM 实验流程（开源版）

本目录为可公开上传版本，已完成以下清理：

- 移除 notebook 输出（避免泄露运行日志、内网信息和硬件细节）
- 删除明文 API Key，改为环境变量 `DEEPSEEK_API_KEY`
- 替换硬编码绝对路径为相对/占位路径
- 删除 `.DS_Store`、`.ipynb_checkpoints`、历史 zip 文件

## 0. 快速提交（GitHub）

```bash
cd glm-hate-speech-experiment
git init
git add .
git commit -m "chore: release sanitized open-source version"
git branch -M main
git remote add origin <your-github-repo-url>
git push -u origin main
```

## 1. 环境准备

```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -r requirements.txt
```

## 2. 配置 API Key

```bash
cp .env.example .env
```

将 `.env` 中的 `DEEPSEEK_API_KEY` 填成你自己的密钥，并在运行前导出：

```bash
export DEEPSEEK_API_KEY="your_real_key"
```

## 3. 路径说明

代码中的模型路径已改为通用形式，例如：

- `models/glm-4-9b-chat-hf`
- `results/sft_models/final_model`
- `results/sft_models/merged_for_inference`

请按本机实际目录调整。

## 4. 安全建议

- 不要提交 `.env` 文件
- 若密钥曾在历史中出现，立即去服务商控制台轮换/删除
- 每次提交前可执行：

```bash
rg -n "sk-[A-Za-z0-9_-]{16,}|/root/autodl-tmp|/Users/"
```

## 5. 许可证与合规

- 代码许可证见 [LICENSE](./LICENSE)
- 数据与模型相关声明见 [NOTICE](./NOTICE) 和 [THIRD_PARTY_LICENSES.md](./THIRD_PARTY_LICENSES.md)
- 提交前请确认你有权公开当前数据与模型文件

## 6. 轻量发布说明

为确保压缩包可上传，本仓库已移除可再生成的大体积产物：

- `results/sft_models/final_model/`
- `results/sft_training_data/`
- `data/processed/`
- `4_SFT微调与实验/*_responses*`

如需完整复现实验，可按 notebook 流程重新生成以上文件。
