# Third-Party Licenses and Notices

This project uses third-party libraries and model tooling. Common dependencies include:

- `transformers`
- `peft`
- `torch`
- `vllm`
- `datasets`
- `scikit-learn`
- `pandas`
- `numpy`
- `tqdm`
- `requests`
- `joblib`

Please review each package's license on PyPI/GitHub before redistribution in your environment.

## Data and Model Artifacts

- `data/` and `results/` may include content derived from third-party datasets or base models.
- Redistribution rights may differ from code license terms.
- Confirm the source dataset/model licenses before public release or commercial usage.
