# Security Policy

## Supported Versions

This repository is research-oriented and does not provide long-term maintenance guarantees.
Please use the latest `main` branch.

## Reporting a Vulnerability

If you discover a security issue (for example, leaked credentials, unsafe defaults, or dependency vulnerabilities), please:

1. Do not open a public issue with sensitive details.
2. Contact the maintainer privately first.
3. Include reproduction steps and impact assessment.

The maintainer will acknowledge receipt and provide follow-up actions as soon as possible.
