# Code of Conduct

We are committed to a respectful and inclusive collaboration environment.

## Expected Behavior

- Be respectful and constructive.
- Focus feedback on ideas and implementation details.
- Assume good intent and communicate clearly.

## Unacceptable Behavior

- Harassment, discrimination, or personal attacks.
- Deliberate intimidation or abusive language.
- Sharing private information without permission.

## Enforcement

Project maintainers may remove comments, reject contributions, or block participation for behavior that violates this code.
