# DDANO: Dual-ended Dynamic Prompts Learning for Zero-Shot Anomaly Detection

Abstract—Zero-shot anomaly detection (ZSAD) aims to identify anomalies in images without relying on training data from specific categories. The key challenge is ensuring the model can generalize effectively to detect anomalies in previously unseen categories. Current methods rely on customizable learnable textual or visual prompts, but this single-modality adaptation limits transferability. To address this, Dual-ended Dynamic Prompts Learning for Zero-Shot Anomaly Detection (DDANO), a novel approach based on the pretrained CLIP model, is proposed to enhance the generalization of unknown anomaly detection. By exploiting learnable object-agnostic dynamic text prompts and generating dynamic visual prompts, the DDANO improves anomaly detection accuracy across diverse scenarios. To further enhance the precision of anomaly localization, Anomaly-Aware Semantic Fusion Module (AASFM) is introduced, which strengthens semantic fusion to effectively highlight anomalous features within the image. Experimental results on industrial and medical anomaly detection datasets demonstrate that compared to classical methods, DDANO significantly enhances ZSAD performance, showing superior generalization and robustness.

Index Terms—Anomaly Detection, Vision-Language Model, Prompt Learning, Zero-shot Learning.

# I. INTRODUCTION

HE goal of Anomaly Detection (AD) [1] is to identify deviations from normal patterns in order to detect potential issues in a timely manner and enable effective interventions. Anomaly detection plays a crucial role in the application of image segmentation, such as industrial defect inspection [2], [3] and medical image analysis [4].

Over the years, various types of anomaly detection approaches have been developed to suit different application scenarios. Anomaly detection can be categorized into three types based on different learning paradigms: unsupervised, semi-supervised, and supervised anomaly detection methods [5]. These approaches typically require labeled normal and anomalous samples for training. For example, to train a model specifically designed to detect defects on bottles, unsupervised learning methods establish a normality model by learning the features of a large number of normal bottle images, and then detect any samples that deviate from this pattern as anomalies. Semi-supervised learning methods rely on a large set of labeled normal bottle images and a small number of annotated anomalous bottle images for training. In contrast, traditional supervised learning methods impose the strictest

requirements, necessitating a large amount of labeled data that includes both normal bottle images and anomalous bottle images with crack annotations.

However, in certain scenarios, collecting a sufficient number of normal images is not feasible. firstly, the system may lack adequate training data during its initial deployment phase [6], [7]. Additionally, the acquisition of normal samples may be restricted by privacy concerns, ethical considerations, or limitations in data sharing [8].

To address this challenge, the paradigm of zero-shot anomaly detection (ZSAD) [6] has emerged, aiming to identify anomalous regions in images from unseen categories, thereby eliminating the dependency on task-specific training data. Given the high requirement for generalization in ZSAD, existing methods are predominantly based on vision-language models (VLMs). In fact, ZSAD can be considered an extension of supervised anomaly detection in terms of generalization. While supervised methods rely on annotations of known anomaly types, ZSAD detects anomalies without requiring such labels.

As a representative method in the ZSAD field, WinCLIP [6] integrates a pretrained vision-language model with manually crafted textual prompts to achieve anomaly localization. However, CLIP’s training on natural image-text pairs [9], [10] limits its sensitivity to domain-specific anomalies, such as industrial defects or medical lesions. Its visual encoder lacks fine-grained perception, and the text encoder is biased toward coarse category-level semantics. This cross-task semantic gap results in poor generalization to subtle anomalies. Adapting VLMs with annotated auxiliary datasets significantly improves ZSAD performance, as shown in Fig. 1.

In anomaly detection, existing VLMs typically rely on static text or image prompts, limiting their generalization in complex scenarios [11], [12]. Moreover, most approaches adopt simple similarity-based computations, lacking deep interaction between image patches and textual features, which impairs finegrained anomaly recognition. To overcome these limitations, this paper proposes a novel method named DDANO. First, DDANO introduces a dual-end dynamic prompting mechanism that allows the model to more effectively utilize both textual and visual information. Second, a projection layer is added after the image encoder, introducing additional learnable parameters to fine-tune CLIP. The prompt layer appends extra prompt tokens to the encoder’s input layers, effectively replacing CLIP’s original transformer layers. In addition, DDANO introduces a novel cross-modal fusion module named AASFM. This module clusters image patches and aggregates the most anomalous regions. An attention mechanism is then applied across the channel dimension of the clustered image features

![](images/0ce4264785fe8df042e771ba0a6ab430a8ce025608030b6defb943595bebb998.jpg)  
Fig. 1. Comparison of pixel-level max-F1 across different datasets with classical methods.

to reweight features, enhancing the model’s focus on critical anomalies. The results demonstrate that DDANO achieves outstanding ZSAD performance across diverse datasets in defect detection and medical image analysis, effectively supporting both anomaly detection and segmentation.

In summary, this paper makes the following contributions.

1) A novel ZSAD method, DDANO incorporates a dualend dynamic prompting mechanism, utilizing learnable, object-agnostic dynamic text prompts and dynamic image prompts. This design removes the reliance on manually defined textual prompts, enhancing the model’s transferability and generalization for more accurate anomaly detection across varied testing scenarios.

2) A cross-modal fusion module, AASFM, is introduced to strengthen the fusion of image embeddings and textual features. AASFM, which is specifically designed to precisely identify and aggregate anomalous regions, optimizes the fusion of image and text data and futher elevates the accuracy of fine-grained anomaly recognition.

# II. RELATED WORK

# A. Supervised Anomaly Detection

Supervised anomaly detection methods require both labeled normal and anomalous samples, and explicitly define the decision boundaries of all target anomaly categories for supervised learning. These methods typically rely on image-level classification labels or pixel-level annotations to directly learn the feature patterns of known anomalies using pre-trained models. For example, [13] addresses open-set supervised anomaly detection by learning disentangled representations for seen, pseudo-anomalous, and latent residual anomalies. In [14], an explicit boundary-guided semi-pull-push contrastive learning method is proposed, which improves the discriminative and generalization ability of supervised anomaly detection models through explicit boundary generation and guided optimization.

Although supervised anomaly detection methods often achieve high accuracy, their performance is typically constrained by the scarcity of defect samples from the target

categories. In contrast, ZSAD methods offer the advantage of enabling cross-domain anomaly detection to unseen categories without requiring training samples from the target class.

# B. Zero-shot Anomaly Detection

Zero-shot learning enables models to recognize unseen categories without target-class training samples. In recent years, Pre-trained VLMs have shown strong zero-shot transferability, offering a new paradigm for open-world anomaly detection. A representative example is WinCLIP [6], which detects anomalies via cross-modal similarity between image patch and text embeddings, and enhances anomaly recognition using text augmentation strategies [15]. However, a domain gap remains between these models’ pre-training objectives and the demands of anomaly detection. To mitigate this, APRL-GAN [16] and CLIP-AD [17] fine-tune CLIP’s projection layers on annotated anomaly datasets to improve adaptability for ZSAD tasks. Building on this foundation, AnomalyCLIP [18] was the first to systematically explore a learnable text prompt paradigm specifically for anomaly detection. By designing dynamic, learnable textual templates and integrating both global and local region features, it significantly enhances CLIP’s sensitivity to industrial defects. Further, AnomalyGPT [19] extends this approach to unsupervised settings by leveraging generative prompting to implicitly model the anomaly distribution. However, its performance is limited by the insufficient utilization of auxiliary data in the unsupervised paradigm. To mitigate the scarcity of anomalous samples, PromptAD [20] introduces the concept of explicit anomaly margin. This approach controls the margin via a hyperparameter, ensuring effective separation between normal and abnormal instances. However, PromptAD requires manually crafted prompt templates for each class, which limits its scalability and flexibility.

Methods such as [18], [20], [21] rely on static modality prompts, which limits the model’s generalization capability in complex scenarios. In addition, approaches like [22], [23] adopt simple similarity-based computations without deep interaction between image patches and textual features, thereby weakening the model’s ability to identify fine-grained anomalies. In this work, to better leverage information from auxiliary data, a dual-end dynamic prompting mechanism is introduced, along with enhanced cross-modal fusion between image embeddings and textual features.

# III. METHODOLOGY

# A. Overview

This paper proposes DDANO, which aims to enhance CLIP’s adaptation for ZSAD through a dual-end dynamic prompting mechanism. As shown in Fig. 2, DDANO first introduces object-agnostic dynamic text prompts on the text side, designing two learnable text prompt templates, $g _ { \mathrm { n } }$ and $g _ { \mathrm { a } }$ , to learn generalized embeddings for normal and anomalous categories, respectively. On the image side, dynamic image prompts are generated to allow the model to fully leverage image information for feature representation. Next, at the end of the image encoder, we introduce a projection layer to ensure good alignment between image and text in a shared space.

![](images/ebabb3d1d756dd059748799ed1ba1ae240179d8505e75daa9e92ec68fbefd381.jpg)  
Fig. 2. Framework of DDANO.

Finally, to strengthen the fusion of image embeddings $F ^ { P }$ and text features $F ^ { T }$ , a cross-modal information fusion module named AASFM is proposed. This module utilizes the K-means clustering algorithm to extract anomalous feature blocks from the image and calculates anomaly scores using an attention mechanism to highlight the most anomalous features in the data, thus improving the model’s performance in anomaly detection.

# B. Prompt Layer

DDANO freezes the pretrained Transformer weights and inserts learnable prompt tokens through the prompt layers, denoted as $L _ { I } ^ { P }$ in the image encoder and $L _ { T } ^ { P }$ in the text encoder, as shown in Fig. 2. Specifically, in the first $J$ layers of both the image encoder and the text encoder, the prompt tokens $P \in \mathbb { R } ^ { M \times C }$ are concatenated with the vanilla tokens $T \in \mathbb { R } ^ { N \times C }$ , where $C$ represents the embedding dimension, the lengths of the prompt and vanilla tokens are denoted by $M$ and $N$ , respectively. In the subsequent layers beyond $J$ , the model only retains the standard forward outputs of the Transformer, without appending new prompt tokens. This design effectively mitigates overfitting while preserving the generalization ability of the pretrained CLIP model, thereby facilitating the model’s adaptation and extension to anomaly detection scenarios. The specific formula is as follows:

$$
[ T _ {j + 1}, - ] = L _ {j} ^ {P} ([ T _ {j}, P _ {j} ]), \quad j \leq J \tag {1}
$$

$$
[ T _ {j + 1}, P _ {j + 1} ] = L _ {j} ^ {P} ([ T _ {j}, P _ {j} ]), \quad j > J \tag {2}
$$

# C. Dual-Ended Dynamic Prompting

To enable the model to better leverage both visual and textual information, dual-end dynamic prompting is introduced, consisting of dynamic text prompts and dynamic image prompts. Traditional text prompt templates, such as “A photo of a [cls]”, primarily focus on the object semantics and fail to capture both normal and anomalous features, limiting their utility in anomaly detection. To support the learning of text embeddings for anomaly discrimination, a common approach is to use templates like “A photo of normal [cls]” and “A photo of damaged [cls]”. However, such templates require manual design, and different descriptions can significantly affect prediction accuracy. Inspired by CoOp [24], we employ learnable dynamic text prompts, eliminating the reliance on traditional fixed templates and the explicit inclusion of object semantics:

![](images/62920cd0ba85d5bff893609aa27ee7b3f0962b2a018a75eccbf29b8e1525c7d9.jpg)  
Fig. 3. Image learnable embeddings

$$
g _ {\mathrm {n}} = \left[ V _ {1} \right] \left[ V _ {2} \right] \dots \left[ V _ {E} \right] [ o b j e c t ] \tag {3}
$$

$$
g _ {\mathrm {a}} = \left[ W _ {1} \right] \left[ W _ {2} \right] \dots \left[ W _ {E} \right] [ d a m a g e d ] [ o b j e c t ] \tag {4}
$$

Where $g _ { \mathrm { n } }$ and $g _ { \mathrm { a } }$ represent the text templates for normal and anomalous categories, respectively. $[ V _ { i } ]$ and $[ W _ { i } ]$ are the learnable word embeddings in the templates. This design not only captures the anomalous features in the image but also avoids the engineering overhead associated with manually defined text prompt templates.

Static prompts are foundational learning tokens shared by all images and are usually used for preliminary adaptation to ZSAD. However, the limitation of static prompts is that they are difficult to adapt to diverse data distributions [25]. To enhance the model’s adaptability and generalization across image types, dynamic image prompts are introduced. Dynamic prompts are generated in real-time for each test image. Specifically, each test image is first passed through a frozen CLIP image encoder, and then dynamic prompts for both the image and text encoders are generated via learnable linear mapping layers, as shown in Fig. 3. These dynamic prompts are adjusted based on the features of each test image, enabling the model to flexibly generate adaptive prompts for different image inputs.

DDANO sums up dynamic text prompts and dynamic image prompts, referred to as dual-end dynamic prompting. In this way, DDANO demonstrates enhanced generalization ability, capable of handling different types of image data, and improving the model’s performance in anomaly detection tasks.

# D. Anomaly-Aware Semantic Fusion Module

DDANO introduces the Anomaly-Aware Semantic Fusion Module (AASFM) to enhance the model’s performance in anomaly detection. Traditional anomaly detection methods typically select the maximum value in the anomaly map as the anomaly score [26]. Although simple and intuitive, this approach is sensitive to noise, which can reduce detection accuracy. In contrast, AASFM integrates K-means clustering with an attention mechanism to highlight the most anomalous features. Specifically, K-means clustering is first applied to patition the image patch embeddings from n layers into $K$ clusters. Then, based on the anomaly map $M$ , an anomaly score is computed for each cluster, and the one with the highest score is selected. Its centroid is aggregated into the semantically enriched image embedding $F ^ { I }$ . This embedding

![](images/2d960a395c81be8b0410c114a443e61f117dd26854613e9605ad2b497657ea22.jpg)

![](images/958d08a60a457a7ed5612a68005eac2d0f8117776a3b0d707226ca61bd8c3dd2.jpg)  
Dot product

![](images/480d03b08cbda6de95879790a0aaf8f852ebfebd742d073db3228dbdb51fbffd.jpg)  
Element-wise add

![](images/54289456f8f3100deac180b7f9f34e971b1751565ce7bfd5f7c90bbc6dc53260.jpg)  
Flatten   
Fig. 4. Structure of Anomaly-Aware Semantic Fusion Module

is then passed through an attention module to generate the attention-refined embedding $F ^ { A }$ that focuses on anomalous regions. Finally, $F ^ { I }$ , $F ^ { A }$ , and the text feature $F ^ { T }$ are fused to strengthen the integration of visual and textual representations. The structure of the attention module is shown in Fig. 4. This module enhances the model’s focus on critical anomalous features by applying channel-wise weighted attention. First, $F _ { s q } ( \cdot )$ applies global average pooling to obtain the channel-wise global response. Then, $F _ { e x } ( \cdot , \mathbf { W } )$ uses two fully connected layers to generate channel-wise weights. Finally, $F _ { s c a l e } ( \cdot , \cdot )$ applies the attention weights to the corresponding channel features to produce the final output $F ^ { A }$ , thereby highlighting the channel features most relevant to anomaly detection.

Previous vision-language anomaly detection methods typically rely on simple dot-product operations between image embeddings and text features, lacking deep interaction between image patches and textual features. To enhance the fusion of image embeddings and textual features, a novel fusion mechanism is proposed. Specifically, after integrating $F ^ { I }$ , $F ^ { A }$ and $F ^ { T }$ , the fused features are split into two separate paths. One path passes through $N$ RepBlocks(with $N$ set to 3) to extract complex feature representations, while the other path directly forwards the input features to preserve the original information. These two paths process the input features at different levels, allowing the model to capture richer semantic information. On this basis, the outputs of the two paths are summed to enhance the model’s representational capacity. Finally, the result is fused with the text features via a dot product operation, further strengthening the correlation between image embeddings and textual features.

# E. Anomaly Score Computation

We derive the anomaly map by computing the cosine similarity between image patch embeddings $F ^ { \bar { P } }$ and the textual

features $F _ { N } ^ { T }$ and $F _ { A } ^ { T }$ . The anomaly map at the $i - t h$ layer is defined as follows:

$$
M _ {i} = \phi \left(\frac {\exp \left(\cos \left(F _ {i} ^ {P} , F _ {A} ^ {T}\right)\right)}{\exp \left(\cos \left(F _ {i} ^ {P} , F _ {N} ^ {T}\right)\right) + \exp \left(\cos \left(F _ {i} ^ {P} , F _ {A} ^ {T}\right)\right)}\right) \tag {5}
$$

Where $\phi$ denotes the reshaping and interpolation function. By computing the similarity between image patch embeddings and textual features at each layer, multiple preliminary anomaly maps are generated and then aggregated to form the final anomaly map $M$ . During training, $M$ is optimized using dice loss [27] and focal loss [28] to improve prediction performance.

After integrating the semantically rich image embedding $F ^ { I }$ , the anomaly-focused image embedding $F ^ { A }$ , and the text feature $F ^ { T }$ , we further fuse the image and text representations to obtain the feature $f _ { c o n c a t }$ . We then perform a dot product between $f _ { c o n c a t }$ and $F ^ { T }$ , followed by softmax normalization to obtain the anomaly score $s$ . This process is formally defined as:

$$
\mathcal {S} = \operatorname {s o f t m a x} (t 1 \cdot f _ {\text {c o n c a t}} \cdot F ^ {T} + t 2 \cdot f _ {\text {i m g}} \cdot F ^ {T}) \quad (6)
$$

Where $f _ { i m g }$ is the result of summing $F ^ { I }$ and $F ^ { A }$ , with thresholds $t 1$ and t2 set to 0.001 and 100, respectively. The anomaly score $s$ is optimized using focal loss.

During training, the total loss $L _ { t o t a l }$ consists of a classification loss $L _ { c l s }$ and a segmentation loss $L _ { s e g }$ , which are defined as follows:

$$
L _ {t o t a l} = L _ {c l s} + L _ {s e g} \tag {7}
$$

$$
L _ {c l s} = \operatorname {F o c a l} \left(\mathcal {S}, S _ {1}\right) \tag {8}
$$

$$
L _ {s e g} = \text {F o c a l} \left(U p \left([ S _ {n, M _ {k}}, S _ {a, M _ {k}} ]\right), S\right) + D i c e ( \begin{array}{l} U _ {c} (S _ {c}, G) \\ I _ {c} (S _ {c}, G) \end{array} )
$$

$$
U p \left(S _ {a, M _ {k}}, S\right)) + D i c e \left(U p \left(S _ {n, M _ {k}}\right), I - S\right)
$$

Where $F o c a l ( \cdot , \cdot )$ and $D i c e ( \cdot , \cdot )$ denote the focal loss and dice loss, respectively. The operators $U p ( \cdot )$ and $[ \cdot , \cdot ]$ represent upsampling and channel-wise concatenation. $S _ { 1 }$ is the groundtruth label for classification, while $S _ { n , M _ { k } }$ and $S _ { a , M _ { k } }$ represent the predicted segmentation masks for normal and anomalous regions, respectively. $S \in \mathbb { R } ^ { H \times W }$ denotes the ground-truth segmentation mask, and $I \in \mathbb { R } ^ { H \times W }$ is an all-one matrix. The classification loss $L _ { c l s }$ evaluates the accuracy of the model’s prediction of whether the entire image is anomalous using focal loss. The segmentation loss $L _ { s e g }$ combines focal loss and dice loss to refine pixel-level localization of anomalous regions and improve segmentation quality.

# IV. EXPERIMENTS AND ANALYSIS

# A. Experimental Setup

Datasets. Our experiments cover 14 publicly available datasets from both industrial and medical domains, representing diverse data types and anomaly detection scenarios. In the industrial domain, we include datasets such as MVTec AD [2], VisA [29], MPDD, BTAD, KSDD, DAGM, and DTD-Synthetic, which are widely used for industrial defect detection, image classification, and anomaly detection tasks. In the medical domain, we consider the brain tumor detection datasets HeadCT, BrainMRI, and $\mathrm { B r } 3 5 \mathrm { H }$ ; the skin cancer detection dataset ISIC; the colorectal polyp detection datasets ClinicDB [30] and ColonDB [31]; and the thyroid nodule detection dataset TN3K. These datasets are extensively used in medical image analysis, disease diagnosis, and tumor detection research.

Evaluation Metrics. In this study, we adopt the Area Under the Receiver Operating Characteristic Curve (AUROC) and the maximum F1 score (max-F1) as the primary metrics for performance evaluation. AUROC, computed at the optimal threshold, measures the model’s classification capability, particularly its accuracy in distinguishing between normal and anomalous samples. The max-F1 score provides a balanced assessment of precision and recall, offering a comprehensive evaluation for imbalanced datasets. During evaluation, we report not only dataset-level results but also domain-level average performance, separately for industrial and medical datasets.

Implementation Details. In this study, we use the pretrained CLIP ( $\mathrm { { V i T - L } } / 1 4 @ 3 3 6 \mathrm { { p x } ) }$ as the default backbone network. To extract image features, we extract patch embeddings from layers 6, 12, 18, and 24 of the CLIP model. During the experiments, all images are resized to a resolution of $5 1 8 \times 5 1 8$ to ensure consistency across both training and testing images. For the ZSAD task, the auxiliary dataset must not contain any categories present in the test set. Although both ClinicDB and ColonDB include data on colorectal polyps, the image features from these datasets show significant visual differences. Therefore, we select MVTec AD and ColonDB as the auxiliary datasets. In the evaluation on MVTec AD and ClinicDB, we use VisA and ClinicDB as the training datasets. During training, the prompt depth $J$ is set to 4, and the prompt length $L$ is set to 5. To train the DDANO model, we perform 30 epochs of training with a learning rate of 0.01.

All experiments are conducted on a single NVIDIA A800 8GB GPU, and the implementation is carried out using the PyTorch-1.9.1 framework.

# B. Experimental Results

In this study, the proposed DDANO is compared with several classical methods, including SAA [32], WinCLIP [6], DINOV2 [33], SAM [34], and APRIL-GAN [16]. Notably, SAA and WinCLIP were not trained using auxiliary datasets.

Zero-Shot Anomaly Detection in the Industrial Domain. Table 1 lists the experimental results obtained from the datasets, which are acquired from industrial domain. It clearly shows that ZSAD methods trained with an auxiliary dataset outperform those trained without such datasets. ZSAD methods using auxiliary datasets demonstrate significant advantages, highlighting that pre-trained vision-language models (VLMs) already possess fundamental knowledge for anomaly detection. Furthermore, as shown in Table 1, the proposed DDANO outperforms other ZSAD methods with a noticeable performance boost. For instance, on the max-F1 metric, DDANO improves by $2 . 1 \%$ at the image level and $2 . 2 \%$ at the pixel level compared to the second-best method. Additionally, DDANO achieved the best overall ranking across all datasets in both image-level and pixel-level performance, solidifying its exceptional performance in ZSAD tasks. To visually demonstrate DDANO’s advantages, we further show the visualization of the cross-domain predicted anomaly maps in Fig. 5. Compared to other ZSAD methods, DDANO provides more accurate anomaly detection results, especially excelling in categories such as hazelnuts and pipes.

Zero-Shot Anomaly Detection in the Medical Domain. Table 2 lists the experimental results from medical domain datasets, revealing trends similar to those observed in the industrial domain. The results show that other ZSAD methods significantly outperform SAA and WinCLIP, highlighting the significant role of auxiliary datasets. In addition, as shown in Table 2, at the image level, DDANO’s performance is second only to APRIL-GAN, while at the pixel level, our method achieves the highest overall ranking. This not only demonstrates DDANO’s outstanding anomaly detection performance in the medical domain but also further validates its excellent generalization ability across different domains. Compared to other ZSAD methods, DDANO shows significant performance advantages in localizing skin cancer regions and colorectal anomalies.

The experimental results indicate that using auxiliary datasets enhances the model’s generalization ability and detection performance. DDANO leverages the auxiliary dataset to further extract the latent anomaly detection knowledge from the pre-trained VLM, resulting in higher accuracy and robustness across multiple domains. The integration of dualend dynamic prompting and the AASFM module not only strengthens the deep fusion of visual and textual features but also effectively improves the model’s ability to localize anomalous regions. Overall, DDANO demonstrates stable and leading detection performance in both industrial and medical domains.

TABLE I COMPARISON OF ZSAD METHODS IN THE INDUSTRIAL DOMAIN. THE BEST PERFORMANCE IS HIGHLIGHTED IN BOLD, AND THE SECOND-BEST PERFORMANCE IS UNDERLINED.   

<table><tr><td>Metric</td><td>Dataset</td><td>SAA</td><td>WinCLIP</td><td>DINOV2</td><td>SAM</td><td>APRIL-GAN</td><td>DDANO</td></tr><tr><td rowspan="7">Image-level (AUROC, max-F1)</td><td>MVTec AD</td><td>(63.5, 87.4)</td><td>(91.8, 92.9)</td><td>(74.4, 87.4)</td><td>(70.8, 86.0)</td><td>(82.3, 88.9)</td><td>(92.7, 93.4)</td></tr><tr><td>VisA</td><td>(67.1, 75.9)</td><td>(78.1, 80.7)</td><td>(75.2, 78.5)</td><td>(61.9, 73.9)</td><td>(81.7, 80.7)</td><td>(87.4, 84.1)</td></tr><tr><td>MPDD</td><td>(42.7, 73.9)</td><td>(61.4, 77.5)</td><td>(62.4, 74.9)</td><td>(63.0, 77.0)</td><td>(66.0, 76.0)</td><td>(68.1, 79.2)</td></tr><tr><td>BTAD</td><td>(59.0, 89.7)</td><td>(68.2, 67.6)</td><td>(79.3, 69.3)</td><td>(89.4, 85.7)</td><td>(85.2, 82.0)</td><td>(89.6, 87.4)</td></tr><tr><td>KSDD</td><td>(68.6, 37.6)</td><td>(93.3, 79.0)</td><td>(94.9, 77.5)</td><td>(65.8,37.9)</td><td>(95.7, 85.2)</td><td>(96.5, 83.0)</td></tr><tr><td>DAGM</td><td>(87.1, 88.8)</td><td>(91.7, 87.6)</td><td>(90.7, 89.2)</td><td>(82.7, 83.6)</td><td>(93.5, 91.8)</td><td>(96.8, 94.1)</td></tr><tr><td>DTD-Synthetic</td><td>(94.4, 93.5)</td><td>(95.1, 94.1)</td><td>(85.8, 93.5)</td><td>(81.9, 91.1)</td><td>(98.1, 96.8)</td><td>(96.0, 94.8)</td></tr><tr><td></td><td>Average</td><td>(68.9, 78.1)</td><td>(82.8, 82.8)</td><td>(80.4, 81.5)</td><td>(73.6, 76.4)</td><td>(86.1, 85.9)</td><td>(89.6, 88.0)</td></tr><tr><td rowspan="7">Image-level (AUROC, max-F1)</td><td>MVTec AD</td><td>(75.5, 38.1)</td><td>(85.1, 31.6)</td><td>(85.9, 39.6)</td><td>(85.4, 29.4)</td><td>(83.7, 39.8)</td><td>(89.3, 45.8)</td></tr><tr><td>VisA</td><td>(76.5, 31.6)</td><td>(79.6, 14.8)</td><td>(95.0, 30.3)</td><td>(92.6, 18.2)</td><td>(95.2, 32.3)</td><td>(95.5, 35.8)</td></tr><tr><td>MPDD</td><td>(81.7, 18.9)</td><td>(71.2, 15.4)</td><td>(95.6, 31.1)</td><td>(94.8, 22.1)</td><td>(95.1, 30.6)</td><td>(95.4, 32.0)</td></tr><tr><td>BTAD</td><td>(65.8, 14.8)</td><td>(72.6, 18.5)</td><td>(91.9, 43.4)</td><td>(93.8, 46.9)</td><td>(89.5, 38.4)</td><td>(89.8, 39.5)</td></tr><tr><td>KSDD</td><td>(78.8, 6.6)</td><td>(95.8, 21.3)</td><td>(99.3, 50.6)</td><td>(91.2, 18.4)</td><td>(98.2., 56.2)</td><td>(97.4, 51.2)</td></tr><tr><td>DAGM</td><td>(62.7, 32.6)</td><td>(81.3, 13.9)</td><td>(90.9, 52.0)</td><td>(88.6, 40.7)</td><td>(90.3, 57.9)</td><td>(94.3, 64.1)</td></tr><tr><td>DTD-Synthetic</td><td>(76.7, 60.6)</td><td>(79.5, 16.1)</td><td>(97.0, 63.4)</td><td>(95.0, 56.7)</td><td>(97.8, 72.7)</td><td>(99.0, 75.0)</td></tr><tr><td></td><td>Average</td><td>(73.9, 29.0)</td><td>(80.7, 18.8)</td><td>(93.7, 44.3)</td><td>(91.7, 33.2)</td><td>(92.8, 46.9)</td><td>(94.4, 49.1)</td></tr></table>

TABLE II COMPARISON OF ZSAD METHODS IN THE MEDICAL DOMAIN. THE BEST PERFORMANCE IS HIGHLIGHTED IN BOLD, AND THE SECOND-BEST PERFORMANCE IS UNDERLINED.   

<table><tr><td>Metric</td><td>Dataset</td><td>SAA</td><td>WinCLIP</td><td>DINOV2</td><td>SAM</td><td>APRIL-GAN</td><td>DDANO</td></tr><tr><td rowspan="4">Image-level (AUROC, max-F1)</td><td>HeadCT</td><td>(46.8, 68.0)</td><td>(84.1, 79.8)</td><td>(71.4, 72.4)</td><td>(78.4, 76.4)</td><td>(93.6, 86.4)</td><td>(93.7, 87.6)</td></tr><tr><td>BrainMRI</td><td>(34.4, 76.7)</td><td>(89.8, 86.3)</td><td>(78.3, 82.7)</td><td>(71.5, 78.9)</td><td>(89.7, 89.5)</td><td>(88.7, 87.2)</td></tr><tr><td>Br35H</td><td>(33.2, 67.3)</td><td>(81.6, 74.4)</td><td>(69.1, 70.5)</td><td>(59.0, 67.2)</td><td>(95.6, 91.0)</td><td>(93.8, 86.1)</td></tr><tr><td>Average</td><td>(38.1, 70.7)</td><td>(85.2, 80.2)</td><td>(72.9, 75.2)</td><td>(69.7, 74.1)</td><td>(93.0, 89.0)</td><td>(92.1, 87.0)</td></tr><tr><td rowspan="5">Pixel-level (AUROC, max-F1)</td><td>ISIC</td><td>(83.8, 74.2)</td><td>(67.1, 48.5)</td><td>(94.2, 79.6)</td><td>(94.2, 81.0)</td><td>(92.1, 77.4)</td><td>(91.3, 74.4)</td></tr><tr><td>ColonDB</td><td>(71.8, 31.5)</td><td>(61.1, 19.6)</td><td>(87.3, 56.5)</td><td>(86.1, 45.7)</td><td>(88.7, 52.6)</td><td>(91.4, 56.9)</td></tr><tr><td>ClinicDB</td><td>(66.2, 29.1)</td><td>(67.1, 24.4)</td><td>(83.3, 56.2)</td><td>(83.5, 43.0)</td><td>(82.5, 51.8)</td><td>(91.0, 61.8)</td></tr><tr><td>TN3K</td><td>(66.8, 32.6)</td><td>(67.2, 30.0)</td><td>(73.3, 35.7)</td><td>(70.1, 32.5)</td><td>(75.9, 36.4)</td><td>(81.5, 45.7)</td></tr><tr><td>Average</td><td>(72.1, 41.8)</td><td>(65.6, 30.6)</td><td>(84.5, 57.0)</td><td>(83.5, 50.5)</td><td>(84.8, 54.6)</td><td>(88.8, 59.7)</td></tr></table>

TABLE III ABLATION RESULTS.   

<table><tr><td>Model</td><td>Prompts</td><td>AASFM</td><td>Image-level</td><td>Pixel-level</td></tr><tr><td>V1</td><td>X</td><td>X</td><td>(81.9, 80.1)</td><td>(95.1, 30.7)</td></tr><tr><td>V2</td><td>✓</td><td>X</td><td>(84.9, 82.5)</td><td>(95.2, 31.8)</td></tr><tr><td>V3</td><td>X</td><td>✓</td><td>(83.7, 82.1)</td><td>(95.4, 33.4)</td></tr><tr><td>V4</td><td>✓</td><td>✓</td><td>(87.4, 84.1)</td><td>(95.5, 35.8)</td></tr></table>

# C. Ablation Study

Table 3 shows the impact of dual-end dynamic prompting and AASFM, particularly in terms of performance on the VisA dataset. By gradually adding these modules, a continuous improvement in the model’s performance can be clearly observed across both image-level and pixel-level metrics (AUROC and max-F1). Specifically, the dual-end dynamic prompting mechanism demonstrates strong generalization capability, effec-

tively adapting to the diverse industrial categories in the VisA dataset. On the other hand, AASFM significantly improves the model’s pixel-level detection metrics. This improvement is attributed to AASFM’s enhancement of the deep interaction between image patch embeddings and text features, enabling the model to more accurately localize anomalous regions. The integration of both modules shows a significant advantage on the VisA dataset, validating the effectiveness and synergy of each module design.

# V. CONCLUSION

In this paper, we propose DDANO, a model for ZSAD tasks that enables anomaly detection in unseen categories without the need for target-class training samples. DDANO utilizes dual-end dynamic prompting to enhance the model’s transferability and generalization. Additionally, we introduce a cross-modal information fusion module, AASFM, which integrates clustering algorithms and attention mechanisms to

![](images/2d850935a9a0b856ebb30e7167e95597abe20e4cb1628373ec0de4dc3d0f9a1f.jpg)

![](images/99e0eaaaf3ec4783446b1ce36493201259b79fda4be2f6649c56087db372473d.jpg)  
Fig. 5. Visualization of anomaly maps for different ZSAD methods.

emphasize the most anomalous features. Through extensive experiments on various datasets from both industrial and medical domains, DDANO demonstrates promising anomaly detection performance. Finally, it is important to note that its generalization ability is, to some extent, influenced by the auxiliary datasets. DDANO’s performance may degrade when there is a significant difference between the test data and the auxiliary training datasets.The future work will focus on improving DDANO’s generalization ability by utilizing more diverse auxiliary datasets. Additionally, it will aim to reduce reliance on labeled datasets through self-supervised learning and the generation of pseudo-labels.

# ACKNOWLEDGMENTS

This work is supported by the National Natural Science Foundation of China (NSFC) (62406001).

# REFERENCES

[1] Y. Cao, X. Xu, J. Zhang, Y. Cheng, X. Huang, G. Pang, and W. Shen, “A survey on visual anomaly detection: Challenge, approach, and prospect,” arXiv preprint arXiv:2401.16402, 2024.   
[2] P. Bergmann, K. Batzner, M. Fauser, D. Sattlegger, and C. Steger, “The mvtec anomaly detection dataset: a comprehensive real-world dataset for unsupervised anomaly detection,” International Journal of Computer Vision, vol. 129, no. 4, pp. 1038–1059, 2021.   
[3] C. Wang, W. Zhu, B.-B. Gao, Z. Gan, J. Zhang, Z. Gu, S. Qian, M. Chen, and L. Ma, “Real-iad: A real-world multi-view dataset for benchmarking versatile industrial anomaly detection,” in Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 2024, pp. 22 883–22 892.   
[4] E. C¸ allı, E. Sogancioglu, B. van Ginneken, K. G. van Leeuwen, and K. Murphy, “Deep learning for chest x-ray analysis: A survey,” Medical image analysis, vol. 72, p. 102125, 2021.   
[5] G. Pang, C. Shen, L. Cao, and A. V. D. Hengel, “Deep learning for anomaly detection: A review,” ACM computing surveys (CSUR), vol. 54, no. 2, pp. 1–38, 2021.   
[6] J. Jeong, Y. Zou, T. Kim, D. Zhang, A. Ravichandran, and O. Dabeer, “Winclip: Zero-/few-shot anomaly classification and segmentation,” in Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 2023, pp. 19 606–19 616.

[7] B. K. Isaac-Medina, Y. F. A. Gaus, N. Bhowmik, and T. P. Breckon, “Towards open-world object-based anomaly detection via self-supervised outlier synthesis,” in European Conference on Computer Vision. Springer, 2024, pp. 196–214.   
[8] G. A. Noghre, S. Yao, A. D. Pazho, B. R. Ardabili, V. Katariya, and H. Tabkhi, “Pheva: A privacy-preserving human-centric video anomaly detection dataset,” arXiv preprint arXiv:2408.14329, 2024.   
[9] A. Radford, J. W. Kim, C. Hallacy, A. Ramesh, G. Goh, S. Agarwal, G. Sastry, A. Askell, P. Mishkin, J. Clark et al., “Learning transferable visual models from natural language supervision,” in International conference on machine learning. PmLR, 2021, pp. 8748–8763.   
[10] C. Schuhmann, R. Vencu, R. Beaumont, R. Kaczmarczyk, C. Mullis, A. Katta, T. Coombes, J. Jitsev, and A. Komatsuzaki, “Laion-400m: Open dataset of clip-filtered 400 million image-text pairs,” arXiv preprint arXiv:2111.02114, 2021.   
[11] Y. Li, A. Goodge, F. Liu, and C.-S. Foo, “Promptad: Zero-shot anomaly detection using text prompts,” in Proceedings of the IEEE/CVF Winter Conference on Applications of Computer Vision, 2024, pp. 1093–1102.   
[12] C. Li, S. Zhou, J. Kong, L. Qi, and H. Xue, “Kanoclip: Zeroshot anomaly detection through knowledge-driven prompt learning and enhanced cross-modal integration,” arXiv preprint arXiv:2501.03786, 2025.   
[13] C. Ding, G. Pang, and C. Shen, “Catching both gray and black swans: Open-set supervised anomaly detection,” in Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, 2022, pp. 7388–7398.   
[14] X. Yao, R. Li, J. Zhang, J. Sun, and C. Zhang, “Explicit boundary guided semi-push-pull contrastive learning for supervised anomaly detection,” in Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 2023, pp. 24 490–24 499.   
[15] M. Tamura, “Random word data augmentation with clip for zero-shot anomaly detection,” arXiv preprint arXiv:2308.11119, 2023.   
[16] X. Chen, Y. Han, and J. Zhang, “April-gan: A zero-/few-shot anomaly classification and segmentation method for cvpr 2023 vand workshop challenge tracks 1&2: 1st place on zero-shot ad and 4th place on fewshot ad,” arXiv preprint arXiv:2305.17382, 2023.   
[17] X. Chen, J. Zhang, G. Tian, H. He, W. Zhang, Y. Wang, C. Wang, and Y. Liu, “Clip-ad: A language-guided staged dual-path model for zeroshot anomaly detection,” in International Joint Conference on Artificial Intelligence. Springer, 2024, pp. 17–33.   
[18] Q. Zhou, G. Pang, Y. Tian, S. He, and J. Chen, “Anomalyclip: Object-agnostic prompt learning for zero-shot anomaly detection,” arXiv preprint arXiv:2310.18961, 2023.   
[19] Z. Gu, B. Zhu, G. Zhu, Y. Chen, M. Tang, and J. Wang, “Anomalygpt: Detecting industrial anomalies using large vision-language models,” in Proceedings of the AAAI conference on artificial intelligence, vol. 38, no. 3, 2024, pp. 1932–1940.   
[20] X. Li, Z. Zhang, X. Tan, C. Chen, Y. Qu, Y. Xie, and L. Ma, “Promptad: Learning prompts with only normal samples for few-shot anomaly detection,” in Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, 2024, pp. 16 838–16 848.   
[21] J. Zhu and G. Pang, “Toward generalist anomaly detection via in-context residual learning with few-shot sample prompts,” in Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, 2024, pp. 17 826–17 836.   
[22] Y. Rao, W. Zhao, G. Chen, Y. Tang, Z. Zhu, G. Huang, J. Zhou, and J. Lu, “Denseclip: Language-guided dense prediction with context-aware prompting,” in Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, 2022, pp. 18 082–18 091.   
[23] H. Deng, Y. Guo, Z. Xu, and Y. Kang, “Ptmnet: Pixel-text matching network for zero-shot anomaly detection,” in 2023 9th International Conference on Big Data and Information Analytics (BigDIA). IEEE, 2023, pp. 781–787.   
[24] K. Zhou, J. Yang, C. C. Loy, and Z. Liu, “Learning to prompt for visionlanguage models,” International Journal of Computer Vision, vol. 130, no. 9, pp. 2337–2348, 2022.   
[25] Y. Zha, J. Wang, T. Dai, B. Chen, Z. Wang, and S.-T. Xia, “Instanceaware dynamic prompt tuning for pre-trained point cloud models,” in Proceedings of the IEEE/CVF International Conference on Computer Vision, 2023, pp. 14 161–14 170.   
[26] Y. Cao, X. Xu, Z. Liu, and W. Shen, “Collaborative discrepancy optimization for reliable image anomaly localization,” IEEE Transactions on Industrial Informatics, vol. 19, no. 11, pp. 10 674–10 683, 2023.   
[27] F. Milletari, N. Navab, and S.-A. Ahmadi, “V-net: Fully convolutional neural networks for volumetric medical image segmentation,” in 2016 fourth international conference on 3D vision (3DV). Ieee, 2016, pp. 565–571.

[28] T.-Y. Lin, P. Goyal, R. Girshick, K. He, and P. Dollar, “Focal loss ´ for dense object detection,” in Proceedings of the IEEE international conference on computer vision, 2017, pp. 2980–2988.   
[29] Y. Zou, J. Jeong, L. Pemula, D. Zhang, and O. Dabeer, “Spot-thedifference self-supervised pre-training for anomaly detection and segmentation,” in European Conference on Computer Vision. Springer, 2022, pp. 392–408.   
[30] J. Bernal, F. J. Sanchez, G. Fern ´ andez-Esparrach, D. Gil, C. Rodr ´ ´ıguez, and F. Vilarino, “Wm-dova maps for accurate polyp highlighting in ˜ colonoscopy: Validation vs. saliency maps from physicians,” Computerized medical imaging and graphics, vol. 43, pp. 99–111, 2015.   
[31] N. Tajbakhsh, S. R. Gurudu, and J. Liang, “Automated polyp detection in colonoscopy videos using shape and context information,” IEEE transactions on medical imaging, vol. 35, no. 2, pp. 630–644, 2015.   
[32] Y. Cao, X. Xu, C. Sun, Y. Cheng, Z. Du, L. Gao, and W. Shen, “Segment any anomaly without training via hybrid prompt regularization,” arXiv preprint arXiv:2305.10724, 2023.   
[33] M. Oquab, T. Darcet, T. Moutakanni, H. Vo, M. Szafraniec, V. Khalidov, P. Fernandez, D. Haziza, F. Massa, A. El-Nouby et al., “Dinov2: Learning robust visual features without supervision,” arXiv preprint arXiv:2304.07193, 2023.   
[34] A. Kirillov, E. Mintun, N. Ravi, H. Mao, C. Rolland, L. Gustafson, T. Xiao, S. Whitehead, A. C. Berg, W.-Y. Lo et al., “Segment anything,” in Proceedings of the IEEE/CVF international conference on computer vision, 2023, pp. 4015–4026.